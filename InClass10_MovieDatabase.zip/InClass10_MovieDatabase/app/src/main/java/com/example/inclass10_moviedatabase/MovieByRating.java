package com.example.inclass10_moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MovieByRating extends AppCompatActivity {
    TextView tv_titeDispr, tv_descDispr, tv_genreDispr, tv_ratingDispr, tvYearDispr, tv_imdb_dispr;
    ImageButton ib_firstr, ib_backr, ib_nextr, ib_lastr;
    Button buttonFinishr;
    private static final String movieName ="NAME";
    private static final String movieDesc ="DESC";
    private static final String movieYear ="YEAR";
    private static final String movieImdb ="IMDB";
    private static final String movieGenre ="GENRE";
    private static final String movieRating ="RATING";
    ArrayList<MovieDb> movieByRatingList = new ArrayList<>();
    int size =0;
    int index =0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_by_rating);
        setTitle("Movie Database");
        tv_titeDispr = (TextView) findViewById(R.id.tv_titeDispr);
        tv_descDispr = (TextView) findViewById(R.id.tv_descDispr);
        tv_genreDispr = (TextView) findViewById(R.id.tv_genreDispr);
        tv_ratingDispr = (TextView) findViewById(R.id.tv_ratingDispr);
        tvYearDispr = (TextView) findViewById(R.id.tvYearDispr);
        tv_imdb_dispr = (TextView) findViewById(R.id.tv_imdb_dispr);
        ib_firstr = (ImageButton) findViewById(R.id.ib_firstr);
        ib_backr = (ImageButton) findViewById(R.id.ib_backr);
        ib_nextr = (ImageButton) findViewById(R.id.ib_nextr);
        ib_lastr = (ImageButton) findViewById(R.id.ib_lastr);
        buttonFinishr = (Button) findViewById(R.id.buttonFinishr);



        MainActivity.db.collection("MovieDatabase")
                .orderBy(movieRating, Query.Direction.DESCENDING)
                .get()
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MovieByRating.this, "No movies present", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_CANCELED);
                    }
                })
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        for(DocumentSnapshot document: task.getResult()){
                            MovieDb movie = new MovieDb();
                            Log.i("demo" ,document.getString(movieName) );
                            movie.setMname(document.getString(movieName));
                            movie.setMyear(Integer.parseInt(document.getString(movieYear)));
                            movie.setGenre(document.getString(movieGenre));
                            movie.setMdesc(document.getString(movieDesc));
                            movie.setMimdb(document.getString(movieImdb));
                            movie.setMrating(document.getLong(movieRating).intValue());
                            movieByRatingList.add(movie);
                        }
                        if(movieByRatingList.size() ==0){
                            Toast.makeText(MovieByRating.this, "No Movies Present!", Toast.LENGTH_SHORT).show();
                            buttonDisplay(false, false, false, false, 127, 127, 127, 127);
                        }else if(movieByRatingList.size() ==1){
                            size = movieByRatingList.size() - 1;
                            displayFunction(index);
                            buttonDisplay(false, false, false, false, 127, 127, 127, 127);
                        }else {
                            size = movieByRatingList.size() - 1;
                            displayFunction(index);
                            buttonDisplay(false, true, false, true, 127, 255, 127, 255);
                        }
                    }
                });



        ib_firstr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = 0;
                buttonDisplay(false, true, false,true ,127, 255,127,255);
                displayFunction(index);

            }
        });


        ib_lastr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = size;
                buttonDisplay(true, false, true,false,255, 127,255,127);
                displayFunction(index);
            }
        });



        ib_nextr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index ++;
                if(index == size){
                    Toast.makeText(MovieByRating.this, "Last Movie in List", Toast.LENGTH_SHORT).show();
                    buttonDisplay(true, false, true,false,255, 127,255,127);

                }else {
                    buttonDisplay(true, true, true, true, 255, 255, 255, 255);
                }
                displayFunction(index);
            }
        });




        ib_backr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index--;
                if(index ==0){
                    buttonDisplay(false, true, false,true ,127, 255,127,255);
                    Toast.makeText(MovieByRating.this, "first Movie in List", Toast.LENGTH_SHORT).show();
                }else{
                    buttonDisplay(true, true, true, true, 255, 255, 255, 255);
                }
                displayFunction(index);

            }
        });


        buttonFinishr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentByyearDone = new Intent();
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    public void displayFunction(int index){
        tv_titeDispr.setText(movieByRatingList.get(index).mname);
        tv_descDispr.setText(movieByRatingList.get(index).mdesc);
        tv_genreDispr.setText(movieByRatingList.get(index).genre);
        tvYearDispr.setText(String.valueOf(movieByRatingList.get(index).myear));
        tv_ratingDispr.setText(String.valueOf(movieByRatingList.get(index).mrating) + " / 5");
        tv_imdb_dispr.setText(movieByRatingList.get(index).mimdb);

    }

    private void buttonDisplay(boolean backr, boolean nextr ,boolean firstr,boolean lastr, int backrAlpha, int nextrAlpha,int firstAlpha, int lastAlpha){
        ib_backr.setEnabled(backr);
        ib_nextr.setEnabled(nextr);
        ib_firstr.setEnabled(firstr);
        ib_lastr.setEnabled(lastr);
        ib_backr.setAlpha(backrAlpha);
        ib_nextr.setAlpha(nextrAlpha);
        ib_firstr.setAlpha(firstAlpha);
        ib_lastr.setAlpha(lastAlpha);


    }
}
