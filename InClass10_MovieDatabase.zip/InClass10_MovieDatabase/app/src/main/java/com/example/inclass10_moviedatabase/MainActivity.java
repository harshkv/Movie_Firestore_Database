package com.example.inclass10_moviedatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static FirebaseFirestore db;
    Button buttonAdd, buttonEdit, buttonDelete, b_list_year, b_list_rating;
    private static final String movieName ="NAME";
    public int REQ_CODE = 100;
    public int REQ_CODE_EDIT = 101;
    public int REQ_CODEYear = 102;
    public int REQ_CODERate =103;
    ArrayList<MovieDb> movieObjects = new ArrayList<>();
    List<String> listMovieName;
    List<String> listName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Movie Database");
        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonEdit = (Button) findViewById(R.id.buttonEdit);
        buttonDelete = (Button) findViewById(R.id.buttonDelete);
        b_list_year = (Button) findViewById(R.id.b_list_year);
        b_list_rating = (Button) findViewById(R.id.b_list_rating);
        db = FirebaseFirestore.getInstance();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddMovieActivity.class);
                startActivityForResult(intent, REQ_CODE);
            }
        });


        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadEditFunction(); }

        });


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadDeleteFunction(); }
        });



        b_list_year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MovieByYearActivity.class);
                startActivityForResult(intent, REQ_CODEYear);

            }
        });

        b_list_rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MovieByRating.class);
                startActivityForResult(intent, REQ_CODERate);

            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE) {
            if (resultCode == RESULT_OK) {

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "REQUEST CANCELLED", Toast.LENGTH_SHORT).show();
            }
        }

      if (requestCode == REQ_CODE_EDIT) {
        if (resultCode == RESULT_OK) {

        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(this, "REQUEST CANCELLED", Toast.LENGTH_SHORT).show();
        }
    }

        if (requestCode == REQ_CODEYear) {
            if (resultCode == RESULT_OK) {

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "REQUEST CANCELLED EMPTY LIST", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == REQ_CODERate) {
            if (resultCode == RESULT_OK) {

            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "REQUEST CANCELLED EMPTY LIST", Toast.LENGTH_SHORT).show();
            }
        }
}


public void loadEditFunction(){
    listMovieName = new ArrayList<>();
    listName = new ArrayList<>();
                db.collection("MovieDatabase").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                listMovieName.add(document.getString(movieName));
                                listName.add(document.getId());
                            }

                            final CharSequence[] items = listMovieName.toArray(new CharSequence[listMovieName.size()]);
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("Pick a Movie");
                            builder.setItems(items, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
//                                    Log.i("demo", "object" + listMovieName.get(which));
                                    Intent intentEdit = new Intent(MainActivity.this, EditMovieActivity.class);
                                    //intentEdit.putExtra("Movie_Key", listMovieName.get(which));
                                    intentEdit.putExtra("Movie_id", listName.get(which));
                                    startActivityForResult(intentEdit, REQ_CODE_EDIT);
                                }
                            });
                            AlertDialog alert = builder.create();
                            alert.show();


                        } else {
                            Log.i("demo", "Error getting documents: ", task.getException());
                        }
                    }
                });


}


public void loadDeleteFunction(){
    listMovieName = new ArrayList<>();
    listName = new ArrayList<>();
    db.collection("MovieDatabase").get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if(task.isSuccessful()){
                        for(QueryDocumentSnapshot document: task.getResult()){
                            listMovieName.add(document.getString(movieName));
                            listName.add(document.getId());
                        }
                        final CharSequence[] items = listMovieName.toArray(new CharSequence[listMovieName.size()]);
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setTitle("Pick a Movie");
                        builder.setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, final int which) {
                                db.collection("MovieDatabase").document(listName.get(which)).delete()
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Toast.makeText(MainActivity.this, "Movie "+listMovieName.get(which) +" Deleted!", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(MainActivity.this, "Movie Deleted!", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();


                    } else {
                        Log.i("demo", "Error getting documents: ", task.getException());
                    }
                }
            });


}




}
