package com.example.inclass10_moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.HashMap;
import java.util.Map;

public class AddMovieActivity extends AppCompatActivity {
    SeekBar seekbar;
    EditText et_name, et_desc, et_Year, et_imdb;
    Spinner spinner_genre;
    TextView sb_Progress;
    Button buttonAddMovie;
    private static final String movieName ="NAME";
    private static final String movieDesc ="DESC";
    private static final String movieYear ="YEAR";
    private static final String movieImdb ="IMDB";
    private static final String movieGenre ="GENRE";
    private static final String movieRating ="RATING";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);
        setTitle("Movie Database");
        seekbar = (SeekBar) findViewById(R.id.seekBar);
        et_name = (EditText) findViewById(R.id.et_name);
        et_desc = (EditText) findViewById(R.id.et_desc);
        sb_Progress = (TextView) findViewById(R.id.sb_Progress);
        spinner_genre = (Spinner) findViewById(R.id.spinner_genre);
        buttonAddMovie = (Button) findViewById(R.id.addMovieButton);
        et_imdb = (EditText) findViewById(R.id.et_imdb);
        et_Year = (EditText) findViewById(R.id.et_Year);
        seekbar.setMax(5);
        sb_Progress.setText("0");
        seekbar.setProgress(0);
        final String[] genreList = new String[]{"Action", "Animation", "Comedy", "Documentary", "Family", "Horror", "Crime", "Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genreList);
        spinner_genre.setAdapter(adapter);

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekBar.setProgress(progress);
                sb_Progress.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });




        buttonAddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMovieFunction();
            }
        });
    }

    private void addMovieFunction() {
        final String name = et_name.getText().toString();
        String desc = et_desc.getText().toString();
        String year = et_Year.getText().toString();
        String imdb = et_imdb.getText().toString();


        if (name.equals("")) {
            et_name.setError("Please provide Movie Name");
        } else if (desc.equals("")) {
            et_desc.setError("Please provide Movie description");
        } else if (year.equals("")) {
            et_Year.setError("Please provide Movie year");
        } else if (imdb.equals("")) {
            et_imdb.setError("Please provide Movie IMDB Link");
        } else {
            final String genreValue = spinner_genre.getSelectedItem().toString();
            int progress = seekbar.getProgress();

            Map<String,Object> movie = new HashMap<>();
            movie.put(movieName,name);
            movie.put(movieDesc,desc);
            movie.put(movieYear,year);
            movie.put(movieImdb,imdb);
            movie.put(movieGenre,genreValue);
            movie.put(movieRating,progress);
            MainActivity.db.collection("MovieDatabase").document(name).set(movie)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(AddMovieActivity.this, "Movie: "+ name + " added!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(AddMovieActivity.this, "Cannot change Movie Name!", Toast.LENGTH_SHORT).show();

                        }
                    });
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
        }

    }
}