package com.example.inclass10_moviedatabase;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class MovieDb implements Serializable {
    String mname;
    String mdesc;
    String genre;
    int mrating;
    int myear;
    String mimdb;


    public MovieDb() {
        this.mname = mname;
        this.mdesc = mdesc;
        this.genre = genre;
        this.mrating = mrating;
        this.myear = myear;
        this.mimdb = mimdb;
    }


    @Override
    public String toString() {
        return "MovieDb{" +
                "mname='" + mname + '\'' +
                ", mdesc='" + mdesc + '\'' +
                ", genre='" + genre + '\'' +
                ", mrating=" + mrating +
                ", myear=" + myear +
                ", mimdb='" + mimdb + '\'' +
                '}';
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getMdesc() {
        return mdesc;
    }

    public void setMdesc(String mdesc) {
        this.mdesc = mdesc;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getMrating() {
        return mrating;
    }

    public void setMrating(int mrating) {
        this.mrating = mrating;
    }

    public int getMyear() {
        return myear;
    }

    public void setMyear(int myear) {
        this.myear = myear;
    }

    public String getMimdb() {
        return mimdb;
    }

    public void setMimdb(String mimdb) {
        this.mimdb = mimdb;
    }





}
