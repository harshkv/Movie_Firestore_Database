package com.example.inclass10_moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MovieByYearActivity extends AppCompatActivity {
    TextView tv_titeDisp, tv_descDisp, tv_genreDisp, tv_ratingDisp, tvYearDisp, tv_imdb_disp;
    ImageButton ib_first, ib_back, ib_next, ib_last;
    Button buttonFinish;
    ArrayList<MovieDb> movieByYearList = new ArrayList<>();
    private static final String movieName ="NAME";
    private static final String movieDesc ="DESC";
    private static final String movieYear ="YEAR";
    private static final String movieImdb ="IMDB";
    private static final String movieGenre ="GENRE";
    private static final String movieRating ="RATING";
    int index =0;
    int size = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_by_year);
        setTitle("Movie Database");
        tv_titeDisp = (TextView) findViewById(R.id.tv_titeDisp);
        tv_descDisp = (TextView) findViewById(R.id.tv_descDisp);
        tv_genreDisp = (TextView) findViewById(R.id.tv_genreDisp);
        tv_ratingDisp = (TextView) findViewById(R.id.tv_ratingDisp);
        tvYearDisp = (TextView) findViewById(R.id.tvYearDisp);
        tv_imdb_disp = (TextView) findViewById(R.id.tv_imdb_disp);
        ib_first = (ImageButton) findViewById(R.id.ib_first);
        ib_back = (ImageButton) findViewById(R.id.ib_back);
        ib_next = (ImageButton) findViewById(R.id.ib_next);
        ib_last = (ImageButton) findViewById(R.id.ib_last);
        buttonFinish = (Button) findViewById(R.id.buttonFinish);


        MainActivity.db.collection("MovieDatabase")
                .orderBy(movieYear)
                .get()
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MovieByYearActivity.this, "No movies present", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_CANCELED);
                    }
                })
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        for(DocumentSnapshot document: task.getResult()){
                            MovieDb movie = new MovieDb();
                            Log.i("demo" ,document.getString(movieName) );
                            movie.setMname(document.getString(movieName));
                            movie.setMyear(Integer.parseInt(document.getString(movieYear)));
                            movie.setGenre(document.getString(movieGenre));
                            movie.setMdesc(document.getString(movieDesc));
                            movie.setMimdb(document.getString(movieImdb));
                            movie.setMrating(document.getLong(movieRating).intValue());
                            movieByYearList.add(movie);
                        }
                            if(movieByYearList.size() ==0){
                                Toast.makeText(MovieByYearActivity.this, "No Movies Present!", Toast.LENGTH_SHORT).show();
                                buttonDisplay(false, false, false, false, 127, 127, 127, 127);
                            }else if(movieByYearList.size() ==1){
                                size = movieByYearList.size() - 1;
                                displayFunction(index);
                                buttonDisplay(false, false, false, false, 127, 127, 127, 127);
                            }else {
                                size = movieByYearList.size() - 1;
                                displayFunction(index);
                                buttonDisplay(false, true, false, true, 127, 255, 127, 255);
                            }
                    }
                });




        ib_first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = 0;
                buttonDisplay(false, true, false,true ,127, 255,127,255);
                displayFunction(index);

            }
        });


        ib_last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = size;
                buttonDisplay(true, false, true,false,255, 127,255,127);
                displayFunction(index);
            }
        });



        ib_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index ++;
                if(index == size){
                    Toast.makeText(MovieByYearActivity.this, "Last Movie in List", Toast.LENGTH_SHORT).show();
                    buttonDisplay(true, false, true,false,255, 127,255,127);

                }else {
                    buttonDisplay(true, true, true, true, 255, 255, 255, 255);
                }
                displayFunction(index);
            }
        });




        ib_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index--;
                if(index ==0){
                    buttonDisplay(false, true, false,true ,127, 255,127,255);
                    Toast.makeText(MovieByYearActivity.this, "first Movie in List", Toast.LENGTH_SHORT).show();
                }else{
                    buttonDisplay(true, true, true, true, 255, 255, 255, 255);
                }
                displayFunction(index);

            }
        });


        buttonFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentByyearDone = new Intent();
                setResult(RESULT_OK);
                finish();
            }
        });

    }

    public void displayFunction(int index){
            tv_titeDisp.setText(movieByYearList.get(index).mname);
            tv_descDisp.setText(movieByYearList.get(index).mdesc);
            tv_genreDisp.setText(movieByYearList.get(index).genre);
            tvYearDisp.setText(String.valueOf(movieByYearList.get(index).myear));
            tv_ratingDisp.setText(String.valueOf(movieByYearList.get(index).mrating) + " / 5");
            tv_imdb_disp.setText(movieByYearList.get(index).mimdb);


    }

    private void buttonDisplay(boolean backr, boolean nextr ,boolean firstr,boolean lastr, int backrAlpha, int nextrAlpha,int firstAlpha, int lastAlpha){
        ib_back.setEnabled(backr);
        ib_next.setEnabled(nextr);
        ib_first.setEnabled(firstr);
        ib_last.setEnabled(lastr);
        ib_back.setAlpha(backrAlpha);
        ib_next.setAlpha(nextrAlpha);
        ib_first.setAlpha(firstAlpha);
        ib_last.setAlpha(lastAlpha);


    }
}
