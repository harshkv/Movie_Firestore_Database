package com.example.inclass10_moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditMovieActivity extends AppCompatActivity {
    EditText et_nameEdit, et_descEdit, et_YearEdit, et_imdbEdit;
    TextView sb_ProgressEdit;
    Button saveMovieButton;
    Spinner spinner_genreEdit;
    SeekBar seekBarEdit;
    private static final String movieName ="NAME";
    private static final String movieDesc ="DESC";
    private static final String movieYear ="YEAR";
    private static final String movieImdb ="IMDB";
    private static final String movieGenre ="GENRE";
    private static final String movieRating ="RATING";
    String movieid ="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);
        setTitle("Movie Database");
        et_nameEdit =(EditText) findViewById(R.id.et_nameEdit);
        et_descEdit =(EditText) findViewById(R.id.et_descEdit);
        sb_ProgressEdit =(TextView) findViewById(R.id.sb_ProgressEdit);
        spinner_genreEdit = (Spinner) findViewById(R.id.spinner_genreEdit);
        saveMovieButton = (Button) findViewById(R.id.saveMovieButton);
        et_imdbEdit= (EditText) findViewById(R.id.et_imdbEdit);
        et_YearEdit = (EditText) findViewById(R.id.et_YearEdit);
        seekBarEdit =(SeekBar) findViewById(R.id.seekBarEdit);
        seekBarEdit.setMax(5);
        final String[] genreList = new String[]{"Action", "Animation", "Comedy" ,"Documentary", "Family","Horror", "Crime", "Others"};
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genreList);



        if(getIntent() != null  && getIntent().getExtras() != null ){
            //String MovieName =getIntent().getExtras().getString("Movie_Key");
            movieid = getIntent().getExtras().getString("Movie_id");

            MainActivity.db.collection("MovieDatabase").document(movieid).get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {

//                            Log.i("demo",documentSnapshot.getString(movieName));
                            et_nameEdit.setText(documentSnapshot.getString(movieName));
                            et_descEdit.setText(documentSnapshot.getString(movieDesc));
                            et_YearEdit.setText(String.valueOf(Long.parseLong(documentSnapshot.getString(movieYear))));
                            et_imdbEdit.setText(documentSnapshot.getString(movieImdb));
                            seekBarEdit.setProgress(documentSnapshot.getLong(movieRating).intValue());
                            spinner_genreEdit.setAdapter(adapter);
                            spinner_genreEdit.setSelection(Arrays.asList(genreList).indexOf(documentSnapshot.getString(movieGenre)));

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.i("demo", "failed");
                        }
                    });

            saveMovieButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final String name = et_nameEdit.getText().toString();
                    String desc = et_descEdit.getText().toString();
                    String year = et_YearEdit.getText().toString();
                    String imdb = et_imdbEdit.getText().toString();


                    if (name.equals("")) {
                        et_nameEdit.setError("Please provide Movie Name");
                    } else if (desc.equals("")) {
                        et_descEdit.setError("Please provide Movie description");
                    } else if (year.equals("")) {
                        et_YearEdit.setError("Please provide Movie year");
                    } else if (imdb.equals("")) {
                        et_imdbEdit.setError("Please provide Movie IMDB Link");
                    } else {
                        final String genreValue = spinner_genreEdit.getSelectedItem().toString();
                        int progress = seekBarEdit.getProgress();

                        Map<String, Object> movie = new HashMap<>();
                        movie.put(movieName, name);
                        movie.put(movieDesc, desc);
                        movie.put(movieYear, year);
                        movie.put(movieImdb, imdb);
                        movie.put(movieGenre, genreValue);
                        movie.put(movieRating, progress);

                        MainActivity.db.collection("MovieDatabase").document(movieid).update(movie)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Toast.makeText(EditMovieActivity.this, "Movie: "+ name + " updated!", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(EditMovieActivity.this, "onFailure "+ e.toString(), Toast.LENGTH_SHORT).show();

                                    }
                                });

                    }

                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();

                }
            });

        }







    }
}
